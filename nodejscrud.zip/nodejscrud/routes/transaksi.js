// var express = require('express')
// var router = express.Router()
//
// var transaksiController = require("../controller/transaksiController")
//
// router.get('/',function (req,res){
//     transaksiController.list(req, res)
// })
// router.get('/',function (req,res){
//     transaksiController.list(req, res)
// })
//
// router.get('/catagories',function (req,res) {
//     transaksiController.catagories(req,res)
// })
//
// router.post('/',function(req, res){
//     transaksiController.add(req,res)
// })